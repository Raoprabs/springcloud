package com.bookAppStore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bookAppStore.entity.Book;
import com.bookAppStore.proxy.BookServiceProxy;

@RestController
public class BookConsumerController {
	
	
	@Autowired
	BookServiceProxy bookServiceProxy;

	
	@GetMapping("/getBookByid/{id}")
	public Book getBookById(@PathVariable("id") int id ) {
		
		Book book=bookServiceProxy.getBookById(id);
		return book;
	}
}
