package com.bookAppStore.entity;

public class Book {
	
	

	private Integer id;
	
	private String title;
	
	private String publisher;

	private int pages;
	
	
	private int year;
	
	
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", publisher=" + publisher + ", pages=" + pages + ", year="
				+ year + "]";
	}
	
	public Book() {
		
	}

	public Book(Integer id, String title, String publisher, int pages, int year) {
		super();
		this.id = id;
		this.title = title;
		this.publisher = publisher;
		this.pages = pages;
		this.year = year;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	
	

}
