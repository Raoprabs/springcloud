package com.bookAppStore.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bookAppStore.entity.Book;
import com.bookAppStore.proxy.BookServiceProxy;

@Component
public class BookServiceFallback implements BookServiceProxy{

	@Override
	public List<Book> getAllBooks() {
		
		return Arrays.asList(new Book());
	}

	@Override
	public Book getBookById(Integer id) {
		
		return new Book(id, "AWS", "publisher5", 500, 2022);
	}

}
