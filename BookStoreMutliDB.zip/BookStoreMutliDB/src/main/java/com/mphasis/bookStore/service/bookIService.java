package com.mphasis.bookStore.service;

import java.util.List;
import java.util.Map;

import com.mphasis.bookStore.entity.Book;

public interface bookIService {
	
	List<Book> getAllBooks();
	
	Book save(Book bookDetails );
	
	Book update(Book bookDetails);
	
	void delete(int id);
	
	Book getBookById(int id);

	List<Book> getAllBooksByTitle(String title);
	
	List<Book> getAllBooksByPublisher(String publisher);
	
	List<Book> getAllBooksByYear(int year);
	
	void patchBook(Map<String, Object> updates,int id);
	

}
