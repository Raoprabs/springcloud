package com.mphasis.bookStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table; 


@Entity
@Table(name="Book")
public class Book {
	
	
	@Id
	@Column(name="book_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "book_title")
	private String title;
	
	@Column(name = "book_publisher")
	private String publisher;
	
	@Column(name="book_pages")
	private int pages;
	
	@Column(name="book_year")
	private int year;
	
	
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", publisher=" + publisher + ", pages=" + pages + ", year="
				+ year + "]";
	}
	
	public Book() {
		
	}

	public Book(Integer id, String title, String publisher, int pages, int year) {
		super();
		this.id = id;
		this.title = title;
		this.publisher = publisher;
		this.pages = pages;
		this.year = year;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	
	

}
