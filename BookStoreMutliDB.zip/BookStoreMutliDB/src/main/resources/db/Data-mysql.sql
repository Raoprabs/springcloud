INSERT INTO mphasisdb.book(book_title, book_publisher, book_pages, book_year) VALUES('.Net',"publisher1",250,2018); 

INSERT INTO mphasisdb.book(book_title, book_publisher, book_pages, book_year) VALUES('Java',"publisher2",350,2020);  

INSERT INTO mphasisdb.book(book_title, book_publisher, book_pages, book_year) VALUES('Angular',"publisher3",150,2013);  

INSERT INTO mphasisdb.book(book_title, book_publisher, book_pages, book_year) VALUES('Spring',"publisher4",250,2019);