package com.mphasis.bookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreMutliDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
